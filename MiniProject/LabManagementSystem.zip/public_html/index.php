<?php

include'Assets/header.php';

?>
<link rel="stylesheet" href="Statics/Style.css" />
<style>
body{
    background-color:#e9e6d5;
}
.placeholders {
    margin-bottom: 30px;
    text-align: center;
}

.placeholders h4 {
    margin-bottom: 0;
}

.placeholder {
    margin-bottom: 20px;
}

.placeholder img {
    display: inline-block;
}
</style>
<br>

<div class="container" id="past" style="padding-left: 15%;">
    <h1 class="page-header">Dashboard</h1>

    <div class="row placeholders" id="ras">
        <div class="col-xs-6 col-sm-3 placeholder">
            <img src="Assets/1.jpeg" width="400" height="500" class="img-responsive" alt="Generic placeholder thumbnail"
                style="height: 160px;">
        </div>
        
         <div class="col-xs-6 col-sm-3 placeholder">
            <img src="Assets/2.jpg" width="400" height="500" class="img-responsive" alt="Generic placeholder thumbnail"
                style="height: 160px;">
        </div>
        
         <div class="col-xs-6 col-sm-3 placeholder">
            <img src="Assets/3.jpg" width="400" height="500" class="img-responsive" alt="Generic placeholder thumbnail"
                style="height: 160px;">
        </div>
        
         <div class="col-xs-6 col-sm-3 placeholder">
            <img src="Assets/4.jpg" width="400" height="500" class="img-responsive" alt="Generic placeholder thumbnail"
                style="height: 160px;">
        </div>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    <!--    <div class="col-xs-6 col-sm-3 placeholder">-->
    <!--        <img src="Assets/2.jpg" width="400" height="500" class="img-responsive" alt="Generic placeholder thumbnail"-->
    <!--            style="height: 160px;">-->
    <!--    </div>-->
    <!--    <div class="col-xs-6 col-sm-3 placeholder">-->
    <!--        <img src="Assets/3.jpg" width="400" height="500" class="img-responsive" alt="Generic placeholder thumbnail"-->
    <!--            style="height: 160px;">-->
    <!--    </div>-->
    <!--    <div class="col-xs-6 col-sm-3 placeholder">-->
    <!--        <img src="Assets/4.jpg" width="400" height="500" class="img-responsive" alt="Generic placeholder thumbnail"-->
    <!--            style="height: 160px;">-->
    <!--    </div>-->
    <!--</div>-->
    <br>
    <hr>
    <div class="container col-12 col-xl-12 col-lg-12 col-md-12 col-sm-12" style="text-align: justify;">
        <h1 style="text-align: center;">About</h1>
        <hr>
        <br>
        <h4>Vidyavardhini means a Body committed to
            enhancement of Knowledge. Vidyavardhini was
            established as a registered society in 1970 by late
            Padmashri H. G. alias Bhausaheb Vartak for the noble
            cause of education in rural areas.
            Vidyavardhini’s College of Engineering and
            Technology, Vasai is located on the sprawling campus
            of Vidyavardhini, spread over an area of 12.27
            acres. It is a short, two minutes walk from Vasai
            Road (W) Railway Station. The college is also
            accessible by road from Mumbai.
            Vidyavardhini Society received approval from
            AICTE to start the new college of Engineering &amp;
            Technology with effect from July, 1994. The college
            is affiliated to the University of Mumbai for the
            four year degree program leading to the degree of
            Bachelor of Engineering.
        </h4>
        <br>
        <hr>
        <h1 style="text-align: center;">Vision</h1>
        <hr>
        <br>
        <h4>
            To be a premier institution of technical education, aiming at
            becoming a valuable resource for industry and society.
        </h4>
        <br>
        <hr>
        <h1 style="text-align: center;">Mission</h1>
        <hr>
        <br>
        <h4>
            <ul>
                <li>To provide technologically inspiring environment for
                    learning.</li>
                <li>To promote creativity, innovation and professional
                    activities.</li>
                <li>To inculcate ethical and moral values.</li>
                <li>To cater personal, professional and societal needs
                    through quality education.</li>
            </ul>
        </h4>
        <br>
        <hr>

    </div>
</div>
<br>
<br><?php

include'Assets/footer.php';

?>