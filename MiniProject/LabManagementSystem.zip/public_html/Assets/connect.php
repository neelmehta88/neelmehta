<?php

$server = "localhost";
$user = "id15478516_student";
$password = "mP1n6]Ye2UOR#UzI";
$db = "id15478516_student_info";

$con = mysqli_connect($server ,$user ,$password ,$db);

if($con){
    ?>
        <script>
            console.log("Connection Successful");
        </script>
    <?php
}else{
    ?>
        <script>
            console.log("No Connection");
        </script>
    <?php
}

?>