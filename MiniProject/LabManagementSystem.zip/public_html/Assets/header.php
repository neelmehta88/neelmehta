<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css"
        href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap.min.css" />
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/responsive/2.2.5/css/responsive.bootstrap.min.css" />
    <link rel="stylesheet" href="../Statics/Style.css" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body onload="tp()" style="overflow-x: hidden;">
    <header>
        <div class="tophead" style="
						background-color: #000000;
						color: #FFD700;
						display: flex;
						justify-content: space-between;
						width: 100%;
						height: 50px;
						align-items: center;
						position: fixed;
                        z-index:1;
					">
            <div class="brandlogo">Student Detail Management System</div>
            <div class="menulines">
                <a href="#" class="mobile-icon" id="mob" onclick="myFunction()"
                    style="text-decoration: none; color: white"><i class="fa fa-bars"></i></a>
            </div>
        </div>
    </header>
    <div class="sidenav" id="mySidenav" style="background-color: black;">
        <h4>
            <ul>
                <li>
                    <a href="../index.php"><i class="fas fa-tachometer-alt"></i>&nbsp;&nbsp;Dashboard</a>
                </li>
                <li>
                    <a href="../View/insert_student.php"><i class="fa fa-plus"></i>&nbsp;&nbsp;Insert Student Detail</a>
                </li>
                
                <li>
                    <a href="../View/view_student.php"><i class="fa fa-eye"></i>&nbsp;&nbsp;View Student
                        Detail</a>
                </li>
                
                
                <li>
                    <a href="../View/update.php"><i class="fa fa-edit"></i>&nbsp;&nbsp;Update Student
                        Detail</a>
                </li>
                
                <li>
                    <a href="../View/delete.php"><i class="fa fa-trash" aria-hidden="true"></i>&nbsp;&nbsp;Delete Student
                        Detail</a>
                </li>
            </ul>
        </h4>
    </div>