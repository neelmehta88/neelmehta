<?php

include'../Assets/header.php';

?>
<?php 
include "../Assets/connect.php" ;
// error_reporting(0);

// for fetching data
$id = $_GET["id"];
$id_number = $_GET["id_number"];
$fname = $_GET["fname"];
$city = $_GET["city"];
$contact = $_GET["contact"];
$dob = $_GET["dob"];

?>
<style>
    body{
        background-color:#FFE4E1;
    }
</style>
<div class="container" id="form" style="padding-left:25% ; padding-top:5%;">
    <form method="GET" enctype="multipart/form-data" class="mainform">
        <div class="form-group">
            <p><h3><b>Edit Students Detials</b></h3></p>
            <input type="hidden" name="id" class="form-control" value='<?php echo $id; ?>'>
            <label for="id_number">Id_number:</label>
            <input type="text" class="form-control" placeholder="Enter ID" id="id_number" name="id_number" required value='<?php echo $id_number; ?>'> 
        </div>
        <div class="form-group">
            <label for="fname">Name:</label>
            <input type="text" class="form-control" placeholder="Enter Name" id="fname" name="fname" required value='<?php echo $fname; ?>'> 
        </div>
        <div class="form-group">
            <label for="city">City:</label>
            <input type="text" class="form-control" placeholder="Enter City" id="city" name="city" required value='<?php echo $city; ?>'>
        </div>
        <div class="form-group">
            <label for="phone">Contact:</label>
            <input type="text" class="form-control" placeholder="Enter Contact" id="contact" name="contact" required value='<?php echo $contact; ?>'>
        </div>
        <div class="form-group">
            <label for="dob">Date of birth:</label>
            <input type="date" class="form-control" placeholder="Enter DD/MM/YY" id="dob" name="dob" required value='<?php echo $dob; ?>'>
        </div>
        <button type="submit" class="btn btn-primary" name="update">Update</button>
    </form>
</div>
<?php
if(isset($_GET['update']))
{
 
  $id = $_GET["id"];
  $id_number = $_GET["id_number"];
  $fname = $_GET["fname"];
  $city = $_GET["city"];
  $contact = $_GET["contact"];
  $dob = $_GET["dob"];

    $update = "UPDATE student SET id_number = '$id_number', fname = '$fname' , city = '$city',contact = '$contact', dob = '$dob' WHERE id = '$id'";
    if(mysqli_query($con, $update))
    {
      echo '<script>alert("data updated")
      window.location = "#" </script>';
      
    }
    else
    {
        echo 'Error: '.mysqli_error($con);
        echo '<script>alert("data not updated")</script>';
    }
    // header("location : view_student.php");
    
}
?>
<?php

include'../Assets/footer.php';

?>