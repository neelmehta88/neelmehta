<?php

include'../Assets/header.php';

?>

<?php
	include("../Assets/connect.php");

?>
<style>
body{
        background-color:#FFE4E1;
    }
    a{
        text-decoration: none;color: black;
    }
</style>
<div class="container" id="ras" style="padding-left:25% ; padding-top:9%;">
    <div class=" col-lg-9 col-md-12 col-sm-12 col-7">
        <div class="table-reponsive">
            <table id="example" class="table table-striped" style="width: 95%;">
                <thead>
                    <tr>
                        <th colspan="5"><h3><b>Update Student Detail</b></h3></th>
                    </tr>
                    <tr>
                        <th>Id_number</th>
                        <th>Fname</th>
                        <th>City</th>
                        <th>Contact</th>
                        <th>DOB</th>
                        <th colspan="3">Action</th>

                    </tr>
                </thead>
                <tbody>
                    <?php
			$sel=mysqli_query($con,"SELECT * FROM student");
			while ($fetch = mysqli_fetch_array($sel))
			{
		?>
                    <tr>
                        <td><?php echo $fetch["id_number"]; ?></td>
                        <td><?php echo $fetch["fname"]; ?></td>
                        <td><?php echo $fetch["city"]; ?></td>
                        <td><?php echo $fetch["contact"]; ?></td>
                        <td><?php echo $fetch["dob"]; ?></td>
                        
                        
                        
                        <td>
                           <?php 
					echo "<button class='btn btn-warning'><a href='edit_student.php?id=$fetch[id]&id_number=$fetch[id_number] & fname=$fetch[fname] & city=$fetch[city] & contact=$fetch[contact] & dob=$fetch[dob]'>Update</a></button>";
				?>
				</td>

                        <td>
                    </tr>

                    <?php 
			}
		?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<?php

include'../Assets/footer.php';

?>