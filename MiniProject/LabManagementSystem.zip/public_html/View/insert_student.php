<?php

include'../Assets/header.php';

?>
<?php 
    include("../Assets/connect.php");

    if(isset($_REQUEST['submit']))
    {
        $id_number = $_REQUEST['id_number'];
        $fname = $_REQUEST['fname'];
        $city = $_REQUEST['city'];
        $contact = $_REQUEST['contact'];
        $dob = $_REQUEST['dob'];

        mysqli_query($con,"insert into student(id_number,fname,city,contact,dob)value('$id_number','$fname','$city','$contact','$dob')");
        header("location:view_student.php");
    }

?>
<style>
    body{
        background-color:#FFE4E1;
    }
</style>
<div class="container" id="form" style="padding-left:25% ; padding-top:5%;">
    <form method="POST" enctype="multipart/form-data" class="mainform">
        <div class="form-group">
            <p><h3><b>Insert Students Details</b></h3></p>
            <label for="id_number">Id_number:</label>
            <input type="text" class="form-control"  id="id_number" placeholder="Enter ID" name="id_number" required>
        </div>
        <div class="form-group">
            <label for="fname">Name:</label>
            <input type="text" class="form-control"  id="fname" placeholder="Enter Name" name="fname" required>
        </div>
        <div class="form-group">
            <label for="city">City:</label>
            <input type="text" class="form-control"  id="city" placeholder="Enter City" name="city" required>
        </div>
        <div class="form-group">
            <label for="phone">Contact:</label>
            <input type="text" class="form-control"  id="contact" placeholder="Enter Contact" name="contact" required>
        </div>
        <div class="form-group">
            <label for="dob">Date of birth:</label>
            <input type="date" class="form-control" id="dob" placeholder="Enter DD/MM/YY" name="dob" required>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<?php

include'../Assets/footer.php';

?>